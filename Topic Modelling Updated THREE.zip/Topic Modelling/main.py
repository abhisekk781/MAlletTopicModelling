#! /usr/bin/env python
# =========================================================================================================================
#   File Name           :   main.py
# -------------------------------------------------------------------------------------------------------------------------
#   Purpose             :   Purpose of this script is to generate topic names and provide the output text 
#   Author              :   Abhisek Kumar
#   Co-Author           :   
#   Creation Date       :   07-January-2021
#   History             :
# -------------------------------------------------------------------------------------------------------------------------
#   Date            | Author                        | Co-Author                                          | Remark
#   07-Jan-2021    | Abhisek Kumar                                         | Initial Release
# =========================================================================================================================
# =========================================================================================================================
# Import required Module

import config
import topicmodellinglda
import daskPrep
import pandas as pd
import logging
import warnings
import traceback
warnings.filterwarnings('ignore' )
import dbinsertion
import psycopg2
import sys
import os
import shutil


def top_asg(pData, pColAsg, pCnt='Count'):
    try:
        pAsgData, pAsgGroup = pd.DataFrame(),[]
        pCountAsg = pData.groupby(pColAsg)[pCnt].sum()
        pAsgGroup = pCountAsg.index.values           
        pAsgData = pData.loc[pData[pColAsg].isin(pAsgGroup)]    
    except Exception as e:
        raise(e)
    return pAsgData, pAsgGroup 


def Filelist(pDir):
    try:
        pData = pd.DataFrame()
        pFiles = []
        for file in os.listdir(pDir):
            pFiles.append(file)
    except Exception as e:
        raise(e)    
    return pFiles


def get_topics(pData, pUploadId, pDesc, pNumWords, pColAsg, gDatabase, stopList, pNumTopics):
    try:
        
        pData['UploadId'] = len(pData)*[pUploadId]
        pData['Count'] = len(pData)*[1]
        pData['Split_Flag'] = len(pData)*['A']
        pData['Split_Status'] = len(pData)*['Initial']
        pData['Split_Number'] = len(pData)*[0]
        pTopicDf = pd.DataFrame()
        _, pAsgGroup = top_asg(pData, pColAsg, 'Count')
        dbinsertion.updateUploadMaster(gDatabase, pUploadId, 'Preprocessing Started (Step 1/3)')
        _, pTopicPreProcessDf = daskPrep.preprocess(pData, pDesc, stopList)
        dbinsertion.updateUploadMaster(gDatabase, pUploadId, 'Preprocessing Completed (Step 1/3)')
        dbinsertion.updateUploadMaster(gDatabase, pUploadId, 'Topic Modelling Started (Step 2/3)')
        # for index in range(len(pAsgGroup)):
            # pAsgData = pTopicPreProcessDf.loc[pTopicPreProcessDf[pColAsg] == pAsgGroup[index]].reset_index(drop=True)  
        # _, pTopicModelDf = topicmodellinglda.topicmodel(pAsgData, pNumWords)
        _, pTopicModelDf = topicmodellinglda.topicmodel(pTopicPreProcessDf, pNumWords, pNumTopics)
        pTopicDf = pTopicDf.append(pTopicModelDf)
        dbinsertion.updateUploadMaster(gDatabase, pUploadId, 'Topic Modelling Completed (Step 2/3)')

    except Exception as e:
        print(traceback.format_exc())
    return pTopicDf



if __name__ == "__main__":
    #Checking for any database connection issue first........
    try:
        pdatabaseConn = dbinsertion.connectDB(config.database, config.user, config.password, config.host, config.port)
    except Exception as e:
        print('Cannot connect to the database. Please try later..')
        sys.exit(0)
              
    #First Iteration..................................  
    #For File Processing
    fileList = Filelist(config.pRootDir)
    if len(fileList)>0:
        for file in fileList:
            try:
                pUploadId = file.split('__', 1)[0]
                dbinsertion.updateUploadMaster(pdatabaseConn, pUploadId, 'ID Not Found. Reading the File...')
                dbinsertion.updateResultMaster(pdatabaseConn, pUploadId, 'Processing')
                dbinsertion.updateIteraionFirst(pdatabaseConn, pUploadId)
                resultData = get_topics(pd.read_excel(os.path.join(config.pRootDir, file)), pUploadId, config.pDesc, config.pNumWords, config.pColAsg, pdatabaseConn, stopList = None, pNumTopics = None)
                dbinsertion.updateUploadMaster(pdatabaseConn, pUploadId, 'Database Transaction Started (Step 3/3)')
                dbinsertion.loadData(pdatabaseConn,resultData)
                dbinsertion.updateUploadMaster(pdatabaseConn, pUploadId, 'Database Transaction Completed (Step 3/3)')
                file = file.split('.')[0]
                resultData.to_excel(config.pOutputDir +str(file)+ '_output.xlsx', index=False)
                dbinsertion.updateResultMaster(pdatabaseConn, pUploadId, 'Completed')
                file = file+'.xlsx'
                shutil.move(os.path.join(config.pRootDir,file), os.path.join(config.pArchiveDir,file))
            except Exception as e:
                shutil.move(os.path.join(config.pRootDir, file), os.path.join(config.pFailedDir, file))
                dbinsertion.updateResultMaster(pdatabaseConn, pUploadId, 'Failed')
                dbinsertion.updateUploadMaster(pdatabaseConn, pUploadId, 'Failed while Processing')
                continue
    

    
    #From Second Iteration Onwards....................
    #For Split Group Functionality
    
    splitIdList = dbinsertion.fetchSplitId(pdatabaseConn)
    for splitId in splitIdList:
        try:
            dbinsertion.updateUploadMaster(pdatabaseConn, splitId, 'ID-'+str(splitId)+' Found, Fetching from Database. Please wait..')
            dbinsertion.updateSplitMaster(pdatabaseConn, splitId, 'Processing')
            dbinsertion.updateResultMaster(pdatabaseConn, splitId, 'Processing')
            category_name, request_number = dbinsertion.fetchSplitParams(pdatabaseConn, splitId)
            processedData = dbinsertion.getSplitDataFrame(pdatabaseConn, splitId, category_name)
            pTopicDf = pd.DataFrame()
            dbinsertion.updateUploadMaster(pdatabaseConn, splitId, 'Topic Modelling Started (Step 1/3)')
            _, pTopicModelDf = topicmodellinglda.topicmodel(processedData, config.pNumWords, pNumTopics = request_number)
            pTopicDf = pTopicDf.append(pTopicModelDf)
            dbinsertion.updateUploadMaster(pdatabaseConn, splitId, 'Topic Modelling Completed (Step 2/3)')
            dbinsertion.updateUploadMaster(pdatabaseConn, splitId, 'Updating Database Again With New Topics (Step 3/3)')
            dbinsertion.loadSplitData(pdatabaseConn, pTopicDf, splitId, category_name, 'Completed')
            dbinsertion.updateSplitMaster(pdatabaseConn, splitId, 'Completed')
            dbinsertion.updateResultMaster(pdatabaseConn, splitId, 'Completed')
        except Exception as e:
            dbinsertion.updateSplitMaster(pdatabaseConn, splitId, 'Failed')
            dbinsertion.updateResultMaster(pdatabaseConn, splitId, 'Failed')
            dbinsertion.updateUploadMaster(pdatabaseConn, splitId, 'Failed while Topic Modelling')
            continue
    
    
    #For Remove Noise Functionality
 
    uploadIdList = dbinsertion.fetchUploadId(pdatabaseConn)
    for pUploadId in uploadIdList:
        try:
            dbinsertion.updateUploadMaster(pdatabaseConn, pUploadId, 'ID-'+str(pUploadId)+' Found, Fetching from Database. Please wait..')
            dbinsertion.updateRemoveMaster(pdatabaseConn, pUploadId, 'Processing')
            dbinsertion.updateResultMaster(pdatabaseConn, pUploadId, 'Processing')
            pData = dbinsertion.getDataFrame(pdatabaseConn, pUploadId)
            stopList = dbinsertion.fetchStopword(pdatabaseConn, pUploadId)
            dbinsertion.updateIteraionMaster(pdatabaseConn, pUploadId)
            resultData = get_topics(pData, pUploadId, config.pDesc, config.pNumWords, config.pColAsg, pdatabaseConn, stopList = stopList, pNumTopics = None)
            file_name = dbinsertion.getFileName(pdatabaseConn, pUploadId)
            file_name = file_name.split('.')[0]
            resultData.to_excel(config.pOutputDir +str(file_name)+ '_output.xlsx', index=False)
            dbinsertion.updateUploadMaster(pdatabaseConn, pUploadId, 'Updating Database Again (Step 3/3)')
            dbinsertion.loadData(pdatabaseConn,resultData)
            dbinsertion.updateUploadMaster(pdatabaseConn, pUploadId, 'Database Updated for ID-'+str(pUploadId)+' (Step 3/3)')
            dbinsertion.updateRemoveMaster(pdatabaseConn, pUploadId, 'Completed')
            dbinsertion.updateResultMaster(pdatabaseConn, pUploadId, 'Completed')
        except Exception as e:
            dbinsertion.updateRemoveMaster(pdatabaseConn, pUploadId, 'Failed')
            dbinsertion.updateResultMaster(pdatabaseConn, pUploadId, 'Failed')
            dbinsertion.updateUploadMaster(pdatabaseConn, pUploadId, 'Failed while Processing')
            continue