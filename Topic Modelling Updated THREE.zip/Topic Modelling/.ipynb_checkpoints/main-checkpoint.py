#! /usr/bin/env python
# =========================================================================================================================
#   File Name           :   main.py
# -------------------------------------------------------------------------------------------------------------------------
#   Purpose             :   Purpose of this script is to generate topic names and provide the output text 
#   Author              :   Abhisek Kumar
#   Co-Author           :   
#   Creation Date       :   07-January-2021
#   History             :
# -------------------------------------------------------------------------------------------------------------------------
#   Date            | Author                        | Co-Author                                          | Remark
#   07-Jan-2021    | Abhisek Kumar                                         | Initial Release
# =========================================================================================================================
# =========================================================================================================================
# Import required Module

import config
import topicmodellinglda
import daskPrep
import pandas as pd
import logging
import warnings
import traceback
warnings.filterwarnings('ignore' )
import dbinsertion
import psycopg2
import sys
import os
import shutil


def top_asg(pData, pColAsg, pCnt='Count'):
    try:
        pAsgData, pAsgGroup = pd.DataFrame(),[]
        pCountAsg = pData.groupby(pColAsg)[pCnt].sum()
        pAsgGroup = pCountAsg.index.values           
        pAsgData = pData.loc[pData[pColAsg].isin(pAsgGroup)]    
    except Exception as e:
        raise(e)
    return pAsgData, pAsgGroup 


def Filelist(pDir):
    try:
        pData = pd.DataFrame()
        pFiles = []
        for file in os.listdir(pDir):
            pFiles.append(file)
    except Exception as e:
        raise(e)    
    return pFiles


def get_topics(pData, pUploadId, pDesc, pNumWords, pColAsg, gDatabase, stopList):
    try:
        # print(pData.columns)
        # sys.exit(0)
        # pData[pDesc] = pData[pDesc].apply(lambda s: str(s))
        # pData[pDesc].fillna("unknown", inplace=True)
        pData['UploadId'] = len(pData)*[pUploadId]
        pData['Count'] = len(pData)*[1]        
        pTopicDf = pd.DataFrame()
        _, pAsgGroup = top_asg(pData, pColAsg, 'Count')
        dbinsertion.updateUploadMaster(gDatabase, pUploadId, 'Preprocessing Started (Step 1/3)')
        _, pTopicPreProcessDf = daskPrep.preprocess(pData, pDesc, stopList)
        dbinsertion.updateUploadMaster(gDatabase, pUploadId, 'Preprocessing Completed (Step 1/3)')
        dbinsertion.updateUploadMaster(gDatabase, pUploadId, 'Topic Modelling Started (Step 2/3)')
        for index in range(len(pAsgGroup)):
            pAsgData = pTopicPreProcessDf.loc[pTopicPreProcessDf[pColAsg] == pAsgGroup[index]].reset_index(drop=True)  
            _, pTopicModelDf = topicmodellinglda.topicmodel(pAsgData, pNumWords)
            pTopicDf = pTopicDf.append(pTopicModelDf)
        dbinsertion.updateUploadMaster(gDatabase, pUploadId, 'Topic Modelling Completed (Step 2/3)')

    except Exception as e:
        print(traceback.format_exc())
    return pTopicDf



if __name__ == "__main__":
    #Checking for any database connection issue first........
    try:
        pdatabaseConn = dbinsertion.connectDB(config.database, config.user, config.password, config.host, config.port)
    except Exception as e:
        print('Cannot connect to the database. Please try later..)
        sys.exit(0)
              
    #First Iteration..................................   
    fileList = Filelist(config.pRootDir)
    if len(fileList)>0:
        for file in fileList:
            try:
                pUploadId = file.split('__', 1)[0]
                dbinsertion.updateUploadMaster(pdatabaseConn, pUploadId, 'ID Not Found. Reading the File...')
                dbinsertion.updateResultMaster(pdatabaseConn, pUploadId, 'Processing')
                dbinsertion.updateIteraionFirst(pdatabaseConn, pUploadId)
                resultData = get_topics(pd.read_excel(os.path.join(config.pRootDir, file)), pUploadId, config.pDesc, config.pNumWords, config.pColAsg, pdatabaseConn, stopList = None)
                dbinsertion.updateUploadMaster(pdatabaseConn, pUploadId, 'Database Transaction Started (Step 3/3)')
                dbinsertion.loadData(pdatabaseConn,resultData)
                dbinsertion.updateUploadMaster(pdatabaseConn, pUploadId, 'Database Transaction Completed (Step 3/3)')
                resultData.to_excel(config.pOutputDir +str(file)+ '_output.xlsx', index=False)
                dbinsertion.updateResultMaster(pdatabaseConn, pUploadId, 'Completed')
                shutil.move(os.path.join(config.pRootDir,file), os.path.join(config.pArchiveDir,file))
            except Exception as e:
                shutil.move(os.path.join(config.pRootDir, file), os.path.join(config.pFailedDir, file))
                dbinsertion.updateResultMaster(pdatabaseConn, pUploadId, 'Failed')
                dbinsertion.updateUploadMaster(pdatabaseConn, pUploadId, 'Failed while Processing')
                continue
              
    #From Second Iteration Onwards....................       
    uploadIdList = dbinsertion.fetchUploadId(pdatabaseConn)
    for int(pUploadId) in uploadIdList:
        try:
            dbinsertion.updateUploadMaster(pdatabaseConn, pUploadId, 'ID-'+str(pUploadId)+' Found, Fetching from Database. Please wait..')
            pData = dbinsertion.getDataFrame(pdatabaseConn, pUploadId)
            stopList = dbinsertion.fetchStopword(pdatabaseConn, pUploadId)
            dbinsertion.updateRemoveMaster(pdatabaseConn, pUploadId, 'Processing')
            dbinsertion.updateResultMaster(pdatabaseConn, pUploadId, 'Processing')
            dbinsertion.updateIteraionMaster(pdatabaseConn, pUploadId)
            resultData = get_topics(pData, pUploadId, config.pDesc, config.pNumWords, config.pColAsg, pdatabaseConn, stopList = stopList)
            dbinsertion.updateUploadMaster(pdatabaseConn, pUploadId, 'Updating Database Again (Step 3/3)')
            dbinsertion.loadData(pdatabaseConn,resultData)
            dbinsertion.updateUploadMaster(pdatabaseConn, pUploadId, 'Database Updated for ID-'+str(pUploadId)+' (Step 3/3)')
            dbinsertion.updateRemoveMaster(pdatabaseConn, pUploadId, 'Completed')
            dbinsertion.updateResultMaster(pdatabaseConn, pUploadId, 'Completed')
        except Exception as e:
            dbinsertion.updateRemoveMaster(pdatabaseConn, pUploadId, 'Pending')
            dbinsertion.updateResultMaster(pdatabaseConn, pUploadId, 'Failed')
            dbinsertion.updateUploadMaster(pdatabaseConn, pUploadId, 'Failed while Processing')
            continue