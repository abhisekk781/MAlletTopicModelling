import psycopg2
import pandas as pd
import traceback
import sys

def connectDB(pdatabase, pUser, pPassword, pHost, pPort):
    database = psycopg2.connect (database = pdatabase, user = pUser, password = pPassword, host = pHost, port = pPort)
    return(database)


def loadData(pDatabase,pData):
    cursor = pDatabase.cursor()
    totalRecordsProcessed = 0
    try:
        for i in range(len(pData)):
                try:
                    #UPDATE
                    queryU = """ UPDATE  topicdata 
                            SET     Ticket_No = %s, Ticket_Type = %s, Ticket_Description = %s, Sample = %s, SolvedWorkgroup = %s,
                                    Topic = %s, UploadId = %s, Topic_Confidence_Level = %s                                                       
                            WHERE   UploadId = %s AND Ticket_No = %s """
                    
                    valuesU = (str(pData.Ticket_No.values[i]), str(pData.Ticket_Type.values[i]), str(pData.Ticket_Description.values[i]), str(pData.Sample.values[i]), str(pData.Solved_Workgroup.values[i]), str(pData.Topic.values[i]), str(pData.UploadId.values[i]), str(pData.Topic_Confidence_Level.values[i]),str(pData.UploadId.values[i]),str(pData.Ticket_No.values[i]))
                    cursor.execute(queryU,valuesU)
                    #INSERT
                    query = """INSERT INTO topicdata ( UploadId,Ticket_No, Ticket_Type, Ticket_Description, Sample, SolvedWorkgroup, Topic, Topic_Confidence_Level) 
                                                     SELECT  %s, %s, %s, %s, %s, %s, %s, %s
                                                     WHERE NOT EXISTS (  SELECT  'x' 
                                                                        FROM    topicdata 
                                                                        WHERE   UploadId = %s AND Ticket_No = %s )""" 

                    values = (str(pData.UploadId.values[i]), str(pData.Ticket_No.values[i]), str(pData.Ticket_Type.values[i]), str(pData.Ticket_Description.values[i]), str(pData.Sample.values[i]), str(pData.Solved_Workgroup.values[i]), str(pData.Topic.values[i]), str(pData.Topic_Confidence_Level.values[i]),str(pData.UploadId.values[i]), str(pData.Ticket_No.values[i]))

                    cursor.execute(query, values)
                    totalRecordsProcessed += 1
                    #Ongoing Commit after 100 rows
                    if( totalRecordsProcessed % 100 == 0 ):
                        pDatabase.commit()
                        print(totalRecordsProcessed, 'rows inserted...')

                except Exception as e:
                    print('Some error occured during row injection.')
                    print('*** ERROR[001]: loadData:', sys.exc_info()[0], str(e), ' Upload Id ', pData.UploadId.values[i])
                    print(traceback.format_exc())               
                    cursor.close()
                    return(-1)
        #Final Commit
        pDatabase.commit()
        cursor.close()
        print('Total', totalRecordsProcessed, ' rows inserted...')
        return (0)
    except Exception as e:
        cursor.close()
        print(traceback.format_exc())
        print('No rows inserted. Some error occured in database connection.')
        return(-1)
    
 
def updateRemoveMaster(pDatabase, pUploadId, pMessage):
    cursor = pDatabase.cursor()
    try:
        query = """UPDATE removenoisedata SET status = %s WHERE uploadid = %s"""
        cursor.execute(query, ( pMessage,str(pUploadId)))
        cursor.close()
        pDatabase.commit()
        return(0)
    except Exception as e:
        cursor.close()
        print('*** ERROR[011]: updateRemoveMaster: ', sys.exc_info()[0],str(e),' Upload Id ', pUploadId)
        return(-1)
        
    
def updateUploadMaster(pDatabase, pUploadId, pMessage):
    cursor = pDatabase.cursor()
    try:
        query = """UPDATE uploaddata SET status = %s WHERE uploadid = %s"""
        cursor.execute(query, ( pMessage,str(pUploadId)))
        cursor.close()
        pDatabase.commit()
        return(0)
    except Exception as e:
        cursor.close()
        print('*** ERROR[011]: updateUploadMaster: ', sys.exc_info()[0],str(e),' Upload Id ', pUploadId)
        return(-1)

    
def updateResultMaster(pDatabase, pUploadId, pMessage):
    cursor = pDatabase.cursor()
    try:
        query = """UPDATE uploaddata SET result = %s WHERE uploadid = %s"""
        cursor.execute(query, ( pMessage,str(pUploadId)))
        cursor.close()
        pDatabase.commit()
        return(0)
    except Exception as e:
        cursor.close()
        print('*** ERROR[012]: updateResultMaster: ', sys.exc_info()[0],str(e),' Upload Id ', pUploadId)
        return(-1)
    

def updateIteraionMaster(pDatabase, pUploadId):
    cursor = pDatabase.cursor()
    try:
        query = """SELECT iteration FROM uploaddata WHERE uploadid = (%s)"""
        cursor.execute(query,(str(pUploadId),))
        iteration = int([l[0] for l in cursor.fetchall()][0])
        iteration+=1
        query = """UPDATE uploaddata SET iteration = %s WHERE uploadid = %s"""
        cursor.execute(query, (str(iteration), str(pUploadId)))
        cursor.close()
        pDatabase.commit()
        return(0)
    except Exception as e:
        cursor.close()
        print('*** ERROR[013]: updateIteraionMaster: ', sys.exc_info()[0],str(e),' Upload Id ', pUploadId)
        return(-1)
    
def updateIteraionFirst(pDatabase, pUploadId):
    cursor = pDatabase.cursor()
    try:
        iteration = 1
        query = """UPDATE uploaddata SET iteration = %s WHERE uploadid = %s"""
        cursor.execute(query, (str(iteration), str(pUploadId)))
        cursor.close()
        pDatabase.commit()
        return(0)
    except Exception as e:
        cursor.close()
        print('*** ERROR[014]: updateIteraionFirst: ', sys.exc_info()[0],str(e),' Upload Id ', pUploadId)
        return(-1)
    
    
def fetchUploadId(pDatabase):
    cursor = pDatabase.cursor()
    try:
        query = """SELECT uploadid FROM removenoisedata WHERE status = 'Pending'"""
        cursor.execute(query)
        ids = list(set([l[0] for l in cursor.fetchall()]))
        cursor.close()
        return ids
    except Exception as e:
        cursor.close()
        print('*** ERROR[015]: fetchUploadId: ', sys.exc_info()[0],str(e))
        return(-1)
    
    
def fetchStopword(pDatabase,pUploadId):
    cursor = pDatabase.cursor()
    try:
        query = """SELECT stopwords FROM removenoisedata WHERE uploadid = (%s)"""
        cursor.execute(query, (str(pUploadId),))
        stopwordlist = [l[0] for l in cursor.fetchall()][0]
        stopwordlist = stopwordlist.replace(" ","")
        stopwordlist = stopwordlist.split(",")
        cursor.close()
        return stopwordlist
    except Exception as e:
        cursor.close()
        print('*** ERROR[016]: fetchStopword: ', sys.exc_info()[0],str(e))
        return(-1)
    
    
def getDataFrame(pDatabase,pUploadId):
    cursor = pDatabase.cursor()
    try:
        query = """SELECT Ticket_No, Ticket_Type, SolvedWorkgroup, Ticket_Description FROM topicdata WHERE uploadid = (%s)"""
        cursor.execute(query, (str(pUploadId),))
        #names = [l[0] for l in cursor.description]
        names = ['Ticket_No', 'Ticket_Type','Solved_Workgroup','Ticket_Description']
        rows = cursor.fetchall()
        pData = pd.DataFrame(rows, columns = names)
        cursor.close()
        return pData
    except Exception as e:
        cursor.close()
        print('*** ERROR[017]: getDataFrame: ', sys.exc_info()[0],str(e))
        return(-1)