import os
pColAsg = 'Solved_Workgroup' #Assignment Group
pDesc = 'Ticket_Description' #Description of ticket 
pNumWords = 4 # Number of words for Topic Name
pRootDir = './data/TestData.xlsx' #Root Directory of PIER folder
numPartitions = 4
pOutputDir = './output/'