import config #any hardcoded value defined from config
import WordCloud #Wordcloud scipt for word cloud presentation
import sentiment #Sentiment value each ticket description
import visualization #it is represnting top keywords 
import preprocessing # pre-processing file
import dbinsertion
import traceback 
import pandas as pd
import sys
import psycopg2
#Desc = config.desc
n = config.num
ngram = config.Ngram
#pNodeName = config.NodeName
#pSubUnit = config.subunit
#pFileName = config.FileName

def main(pData, pDatabase, pUploadId, n = n, pNodeName = None, ngram = ngram, Desc = None, sntmnt=False, wrdcld=False, viz=True, Market=False, is_preprocess = False):
    try: 
        if is_preprocess:
            lstatusPreprocessing,pDataProcess = preprocessing.preprocess(pData, Desc)
            pDataProcess = pDataProcess.reset_index()
            pDataProcess = pDataProcess[~pDataProcess.Sample.str.contains("nan", regex=False, na=False)]
        else:
            pDataProcess = pData
            pDataProcess['Sample'] = pData.Sample
        if Market:
            pMarketUnitList = pDataProcess[pSubUnit].unique().tolist()
            for index in range(len(pMarketUnitList)):
                pMarketUnitData = pDataProcess.loc[pDataProcess[pSubUnit] == pMarketUnitList[index]]
                if sntmnt:
                    sentiment.sentiment(pMarketUnitData, Desc = pDataProcess['Sample'], filename=str(pMarketUnitList[index]))
                if wrdcld:
                    WordCloud.plotwordcloud(pMarketUnitData, Desc = pDataProcess['Sample'], filename=str(pMarketUnitList[index]))
                if viz:
                    visualization.plotmostfrqKwds(pMarketUnitData, n, filename=str(pMarketUnitList[index]))
                    visualization.plotFreqngram(pMarketUnitData, n, ngram, filename=str(pMarketUnitList[index]))
                    visualization.plotngramnetwork(pMarketUnitData, pNodeName, filename=str(pMarketUnitList[index]))
        else:
            if sntmnt:
                sentiment.sentiment(pDataProcess, Desc = pDataProcess['Sample'], filename = 'AllData')
            if wrdcld:
                WordCloud.plotwordcloud(pDataProcess, Desc = pDataProcess['Sample'], filename = 'AllData')
            ###### This is getting executed
            if viz:
                #visualization.plotmostfrqKwds(pDataProcess, n, filename = 'AllData')
                visualization.plotFreqngram(pDataProcess, n, ngram, pDatabase, pUploadId)
                #visualization.plotngramnetwork(pDataProcess, pNodeName, filename = 'AllData')
                #visualization.plottablefrqKwds(pDataProcess, n, filename = 'AllData')              
            
    except Exception as e:
        print('Error ocurred main file')
        print(traceback.format_exc())
        return(-1)
    return (0)

if __name__ == "__main__":
        
    uploadId = str(sys.argv[1])
    
    try:
        pdatabaseConn = dbinsertion.connectDB(config.database, config.user, config.password, config.host, config.port)
    except Exception as e:
        print('Cannot connect to the database. Please try later..)
        sys.exit(0)
    
    try:
        Data = dbinsertion.getDataFrame(pdatabaseConn,uploadId)
        main(Data,pdatabaseConn,uploadId)
    