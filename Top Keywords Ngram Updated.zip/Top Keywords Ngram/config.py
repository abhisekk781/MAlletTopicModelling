import os
database = 'postgres'
user = 'postgres'
password = 'postgres'
host = 'localhost'
port = '5432'
num = 25 #slect number of Top Keywords
Ngram = 3 # number of grams