import psycopg2
import traceback
import sys


def connectDB(pdatabase, pUser, pPassword, pHost, pPort):
    database = psycopg2.connect(database=pdatabase, user=pUser, password=pPassword, host=pHost, port=pPort)
    return (database)
    
    
def getDataFrame(pDatabase,pUploadId):
    cursor = pDatabase.cursor()
    try:
        query = """SELECT Sample FROM topicdata WHERE uploadid = (%s)"""
        cursor.execute(query, (str(pUploadId),))
        names = ['Sample']
        rows = cursor.fetchall()
        pData = pd.DataFrame(rows, columns = names)
        cursor.close()
        return pData
    except Exception as e:
        cursor.close()
        print('*** ERROR[021]: getDataFrame: ', sys.exc_info()[0],str(e))
        return(-1)


def loadNgramTable(pDatabase,pData,pUploadId):
    cursor = pDatabase.cursor()
    totalRecordsProcessed = 0
    try:
        for i in range(len(pData)):
                try:
                    #UPDATE
                    query = """ UPDATE  NgramTable 
                            SET     NgramKeyword = %s, UploadId = %s, count = %s                                                       
                            WHERE   UploadId = %s"""
                    
                    cursor.execute(query,(str(pData['NgramKeyword'].values[i]),str(pUploadId),str(pData['count'].values[i]),str(pUploadId)))
                    #INSERT
                    query = """INSERT INTO NgramTable (NgramKeyword,count) 
                                                     SELECT  %s, %s
                                                     WHERE NOT EXISTS ( SELECT  'x' 
                                                                        FROM    NgramTable 
                                                                        WHERE   UploadId = %s)""" 


                    cursor.execute(query, (str(pData['NgramKeyword'].values[i]),str(pUploadId),str(pData['count'].values[i]),str(pUploadId)))
                    totalRecordsProcessed += 1
                    #Ongoing Commit after 10 rows
                    if( totalRecordsProcessed % 10 == 0 ):
                        pDatabase.commit()
                        print(totalRecordsProcessed, 'rows inserted...')

                except Exception as e:
                    print('Some error occured during row injection.')
                    print('*** ERROR[022]: loadNgramTable:', sys.exc_info()[0], str(e), ' Upload ID: ',pUploadId)
                    print(traceback.format_exc())               
                    cursor.close()
                    return(-1)
        #Final Commit
        pDatabase.commit()
        cursor.close()
        print('Total', totalRecordsProcessed, ' rows inserted...')
        return (0)
    except Exception as e:
        cursor.close()
        print(traceback.format_exc())
        print('No rows inserted. Some error occured in database connection.')
        return(-1)
        


def loadData(pDatabase, pData):
    cursor = pDatabase.cursor()
    #cursor.execute("""TRUNCATE TABLE topicdata""")
    totalRecordsProcessed = 0
    try:
        for i in range(len(pData)):
            try:
                # INSERT
                query = """INSERT INTO topicdata (Ticket_No, Ticket_Type, Ticket_Description, Sample, SolvedWorkgroup, Topic) VALUES(%s,%s,%s,%s,%s,%s)"""

                values = (str(pData.Ticket_No.values[i]), str(pData.Ticket_Type.values[i]), str(pData.Ticket_Description.values[i]),
                          str(pData.Sample.values[i]), str(pData.Solved_Workgroup.values[i]), str(pData.Topic.values[i]))

                cursor.execute(query, values)
                totalRecordsProcessed += 1
                # Ongoing Commit after 100 rows
                if (totalRecordsProcessed % 100 == 0):
                    pDatabase.commit()
                    print(totalRecordsProcessed, 'rows inserted...')

            except Exception as e:
                # print('Some error occured during row injection.')
                print(traceback.format_exc())
                # pDatabase.rollback()
                # cursor.close()
                return (-1)
                #continue
        # Final Commit
        pDatabase.commit()
        cursor.close()
        print('Total', totalRecordsProcessed, ' rows inserted out of ', len(pData))
        print('Successful...!!')
        return (0)
    except Exception as e:
        print(traceback.format_exc())
        print('No rows inserted. Some error occured in database connection.')
        return (-1)
